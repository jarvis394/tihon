module.exports.run = async ({ update, args }) => {
  return update.send('')
}

module.exports.command = {
  arguments: false,
  description: {
    en: '',
    ru: '',
  },
  alias: [],
}
