module.exports = [
  {
    function: async user => await user.add(5000),
    text: 'Промокод на 5к Т',
  },
  {
    function: async user => await user.add(5000),
    text: 'Промокод на 5к Т',
  },
  {
    function: async user => await user.add(5000),
    text: 'Промокод на 5к Т',
  },
  {
    function: async user => await user.add(5000),
    text: 'Промокод на 5к Т',
  },
  {
    function: async user => await user.add(5000),
    text: 'Промокод на 5к Т',
  },

  {
    function: async user => await user.add(10000),
    text: 'Промокод на 10к Т',
  },
  {
    function: async user => await user.add(10000),
    text: 'Промокод на 10к Т',
  },
  {
    function: async user => await user.add(10000),
    text: 'Промокод на 10к Т',
  },

  {
    function: async user => await user.add(15000),
    text: 'Промокод на 15к Т',
  },
  {
    function: async user => await user.add(15000),
    text: 'Промокод на 15к Т',
  },

  {
    function: async user => await user.add(20000),
    text: 'Промокод на 20к Т',
  },

  {
    function: async user => await user.add(25000),
    text: 'Промокод на 25к Т',
  },

  {
    function: async user => await user.addReputation(50),
    text: 'Промокод на 50 R',
  },
  {
    function: async user => await user.addReputation(50),
    text: 'Промокод на 50 R',
  },
  {
    function: async user => await user.addReputation(50),
    text: 'Промокод на 50 R',
  },
  {
    function: async user => await user.addReputation(50),
    text: 'Промокод на 50 R',
  },
  {
    function: async user => await user.addReputation(50),
    text: 'Промокод на 50 R',
  },

  {
    function: async user => await user.addReputation(100),
    text: 'Промокод на 100 R',
  },
  {
    function: async user => await user.addReputation(100),
    text: 'Промокод на 100 R',
  },
  {
    function: async user => await user.addReputation(100),
    text: 'Промокод на 100 R',
  },

  {
    function: async user => await user.addReputation(150),
    text: 'Промокод на 150 R',
  },
  {
    function: async user => await user.addReputation(150),
    text: 'Промокод на 150 R',
  },

  {
    function: async user => await user.addReputation(200),
    text: 'Промокод на 200 R',
  },

  {
    function: async user => await user.addReputation(500),
    text: 'Промокод на 500 R',
  },

  {
    function: async user => await user.addReputation(1000),
    text: 'Промокод на 1000 R',
  },
]
