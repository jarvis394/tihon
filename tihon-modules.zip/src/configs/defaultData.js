const USER = {
  money: 0,
  reputation: 0,
  guild: null,
  hidden: 'false',
}

module.exports = {
  USER,
}
