/**
 * Bot token
 */
const TOKEN = process.env.TOKEN

/**
 * Secret for secret purposes
 */
const SECRET = process.env.SECRET

module.exports = {
  TOKEN,
  SECRET,
}
