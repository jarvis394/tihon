exports.run = async ({ update, args }) => {
  update.someRandomFunction()
}

exports.command = {
  hidden: true,
}
